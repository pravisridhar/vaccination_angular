export interface FilterOption {
    key: string;
    column : string;
    type : string;
    criteria : string[];
    operator: string[];
    values: any[];
}