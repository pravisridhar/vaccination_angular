import { FilterOption } from "./FilterOption.model";

export interface TableOption {
    uiTable: string;
    filterOptions: FilterOption[];
}