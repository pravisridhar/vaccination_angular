export class SearchParameter {
    table : string;
    key : string;
    criteria : string;
    operator : string;
    value : any;
    selected : boolean;

    constructor(
        table : string,
        key : string,
        criteria : string,
        operator : string,
        value : any,
        selected : boolean
    ) {
        this.table = table;
        this.key = key;
        this.criteria = criteria;
        this.operator = operator;
        this.value = value;
        this.selected = selected;
    }
}