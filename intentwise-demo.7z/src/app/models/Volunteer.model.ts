export class Volunteer {
    volunteerCode : string;
    professionType : string;

    constructor(volunteerCode: string, professionType: string) {
        this.volunteerCode = volunteerCode;
        this.professionType = professionType;
    }
}