export class VaccinationCentre {
    centreCode : string;
    location: string;
    zone: string;
    centreType : string;
    serviceCharge : number;

    constructor(
        centreCode: string,
        location : string,
        zone: string,
        centreType: string,
        serviceCharge: number
    ) {
        this.centreCode = centreCode;
        this.location = location;
        this.zone = zone;
        this.centreType = centreType;
        this.serviceCharge = serviceCharge;
    }
}