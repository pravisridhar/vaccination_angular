import { VaccinationCentre } from "./VaccinationCentre.model";
import { Volunteer } from "./Volunteer.model";

export class VaccinationRecord {
    [key: string]: number | string | boolean | Date | Volunteer | VaccinationCentre;
    account : string;
    name : string;
    age : number;
    gender : string;
    vaccine : string;
    dose : number;
    registrationType : string;
    paymentType : string;
    profession : string;
    volunteer : Volunteer;
    vaccinationDate : Date;
    vaccinationCentre : VaccinationCentre;

    constructor(account : string,
        name : string,
        age : number,
        gender : string,
        vaccine : string,
        dose : number,
        registrationType : string,
        paymentType : string,
        profession : string,
        volunteer : Volunteer,
        vaccinationDate : Date,
        vaccinationCentre : VaccinationCentre) {
            this.account = account;
            this.name = name;
            this.age = age;
            this.gender = gender;
            this.vaccine = vaccine;
            this.dose = dose;
            this.registrationType = registrationType;
            this.paymentType = paymentType;
            this.profession = profession;
            this.volunteer = volunteer;
            this.vaccinationDate = vaccinationDate;
            this.vaccinationCentre = vaccinationCentre;               
    }
}