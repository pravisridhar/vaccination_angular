import { Injectable } from '@angular/core';
import vaccinationData from '../../assets/data/vaccination-data.json';
import tableOptionsData from '../../assets/data/table-options-data.json';
import { TableOption } from '../models/TableOption.model';
import { VaccinationRecord } from '../models/VaccinationRecord.model';
import { FilterOption } from '../models/FilterOption.model';
import { SearchParameter } from '../models/SearchParameter.model';

@Injectable({
  providedIn: 'root',
})
export class VaccinationService {
  private vaccinationRecords: VaccinationRecord[] = [];
  private filterOptions: FilterOption[] = [];
  private searchParameters: SearchParameter[] = [];
  private filteredRecords: VaccinationRecord[] = [];

  constructor() {}

  getVaccinationData() {
    this.vaccinationRecords = vaccinationData;
    this.filteredRecords = this.vaccinationRecords;
    return this.vaccinationRecords;
  }

  getFilterOptions(tableName: string): FilterOption[] {
    this.filterOptions = tableOptionsData.filter(
        (tableOption: { uiTable: string }) =>
          tableOption.uiTable === tableName
      )[0].filterOptions;
    return this.filterOptions;
  }

  updateSearchFilterParameters(searchParams: SearchParameter[]) {
    this.searchParameters.push(...searchParams);
    return true;
  }

  fetchSearchParameters() {
    return this.searchParameters;
  }

  processNewSearch() {
    this.searchParameters.map(
      searchParam => {
        this.filteredRecords = this.filterVaccinationRecordsBySearchParameter(
          this.filteredRecords,
          searchParam.key,
          searchParam.operator,
          searchParam.value)
      }
    );
    return this.filteredRecords;
  }

  filterVaccinationRecordsBySearchParameter(filteredRecords : VaccinationRecord[], attribute: string, operator: string, value: any) {
    return filteredRecords.filter(
      record => {
        console.log(record[attribute]);
        if(operator == "equals" && record[attribute] == value) {
          return true;
        }
        else if(operator == "greater_than_equals" && record[attribute] >= value) {
          return true;
        }
        else if(operator == "greater_than" && record[attribute] > value) {
          return true;
        }
        else if(operator == "less_than_equals" && record[attribute] <= value) {
          return true;
        }
        else if(operator == "less_than" && record[attribute] < value) {
          return true;
        }
        return false;
      }
    );
  }
}
