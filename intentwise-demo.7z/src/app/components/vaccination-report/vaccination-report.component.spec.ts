import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VaccinationReportComponent } from './vaccination-report.component';

describe('VaccinationReportComponent', () => {
  let component: VaccinationReportComponent;
  let fixture: ComponentFixture<VaccinationReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VaccinationReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VaccinationReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
