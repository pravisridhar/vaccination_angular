import { Component, OnInit } from '@angular/core';
import { VaccinationRecord } from 'src/app/models/VaccinationRecord.model';
import { VaccinationService } from 'src/app/services/vaccination.service';

@Component({
  selector: 'app-vaccination-report',
  templateUrl: './vaccination-report.component.html',
  styleUrls: ['./vaccination-report.component.css']
})
export class VaccinationReportComponent implements OnInit {

  vacctionationReport : VaccinationRecord[] = [];

  constructor(private vaccinationService: VaccinationService) { }

  ngOnInit(): void {
    this.vacctionationReport = this.vaccinationService.getVaccinationData();
  }

  filterUpdateHandler(status: boolean) {
    if(status)
    this.vacctionationReport = this.vaccinationService.processNewSearch();
    console.log('New Search Result... ', this.vacctionationReport);
  }

}
