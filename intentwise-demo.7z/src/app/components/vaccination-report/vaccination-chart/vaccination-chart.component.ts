import { Component, Input, OnInit } from '@angular/core';
import { Chart, registerables } from 'node_modules/chart.js';
import { VaccinationRecord } from 'src/app/models/VaccinationRecord.model';

@Component({
  selector: 'app-vaccination-chart',
  templateUrl: './vaccination-chart.component.html',
  styleUrls: ['./vaccination-chart.component.css'],
})
export class VaccinationChartComponent implements OnInit {
  @Input() vaccinationData!: any[];
  vaccinationList: VaccinationRecord[] = [];
  chart!: Chart;

  x_axis_labels: string[] = [];
  
  covishieldData: number[] = [];
  covaxinData: number[] = [];

  dose1Data: number[] = [];
  dose2Data: number[] = [];

  constructor() {}

  ngOnInit(): void {
    this.vaccinationList = this.vaccinationData;

    Chart.register(...registerables);

    this.configureChart();

    this.chart = new Chart('vaccinationChart', {
      type: 'line',
      data: {
        labels: this.x_axis_labels,
        datasets: [
          {
            label: 'Covishield',
            data: this.covishieldData,
            fill: false,
            borderColor: 'green',
            tension: 0.1,
          },
          {
            label: 'Covaxin',
            data: this.covaxinData,
            fill: false,
            borderColor: 'blue',
            tension: 0.1,
          },
          {
            label: 'Dose 1',
            data: this.dose1Data,
            fill: false,
            borderColor: 'violet',
            tension: 0.1,
          },
          {
            label: 'Dose 2',
            data: this.dose2Data,
            fill: false,
            borderColor: 'purple',
            tension: 0.1,
          }
        ],
      },
    });
  }

  ngOnChanges(): void {
    this.vaccinationList = this.vaccinationData;
    this.chart.data.datasets.length = 0;

    this.x_axis_labels = [];
    this.covishieldData = [];
    this.covaxinData = [];

    //call update method
    this.chart.update();

    this.configureChart();

    let dataSet = [
      {
        label: 'Covishield',
        data: this.covishieldData,
        fill: false,
        borderColor: 'green',
        tension: 0.1,
      },
      {
        label: 'Covaxin',
        data: this.covaxinData,
        fill: false,
        borderColor: 'blue',
        tension: 0.1,
      },
      {
        label: 'Dose 1',
        data: this.dose1Data,
        fill: false,
        borderColor: 'violet',
        tension: 0.1,
      },
      {
        label: 'Dose 1',
        data: this.dose2Data,
        fill: false,
        borderColor: 'purple',
        tension: 0.1,
      }
    ];

    this.chart.data.datasets = dataSet;
    this.chart.update();
  }

  configureChart() {
    let monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    let today = new Date();
    let monthStartDay = new Date();
    let month;

    for (let i = 6; i > 0; i -= 1) {
      monthStartDay = new Date(today.getFullYear(), today.getMonth() - i, 1);
      if (monthStartDay.getMonth() == 11) month = monthNames[0];
      else month = monthNames[monthStartDay.getMonth() + 1];
      this.x_axis_labels.push(month + ' ' + monthStartDay.getFullYear());

      let covishieldCount = 0;
      let covaxinCount = 0;

      let dose1Count = 0;
      let dose2Count = 0;

      this.vaccinationList.map((record) => {
        let vaccineDate = new Date(record.vaccinationDate);
        if (
          vaccineDate.getFullYear() == monthStartDay.getFullYear() &&
          vaccineDate.getMonth() == monthStartDay.getMonth()
        ) {
          if (record.vaccine == 'Covishield') covishieldCount++;
          else if (record.vaccine == 'Covaxin') covaxinCount++;

          if (record.dose == 1) dose1Count++;
          else if (record.dose == 2) dose2Count++;
        }
      });
      this.covishieldData.push(covishieldCount);
      this.covaxinData.push(covaxinCount);

      this.dose1Data.push(dose1Count);
      this.dose2Data.push(dose2Count);
    }
  }
}
