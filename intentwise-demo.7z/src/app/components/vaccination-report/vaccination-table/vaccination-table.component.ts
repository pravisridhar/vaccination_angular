import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { VaccinationCentre } from 'src/app/models/VaccinationCentre.model';
import { VaccinationRecord } from 'src/app/models/VaccinationRecord.model';
import { Volunteer } from 'src/app/models/Volunteer.model';

@Component({
  selector: 'app-vaccination-table',
  templateUrl: './vaccination-table.component.html',
  styleUrls: ['./vaccination-table.component.css']
})
export class VaccinationTableComponent implements OnInit, OnChanges {

  @Input() vaccinationData!: any[];
  
  vaccinationList : VaccinationRecord [] = [];
 
  constructor() { }

  ngOnInit(): void {
    this.vaccinationList = this.vaccinationData;
  }

  ngOnChanges(): void {
    this.vaccinationList = this.vaccinationData;
  }
}
