import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OptionCriteriaComponent } from './option-criteria.component';

describe('OptionCriteriaComponent', () => {
  let component: OptionCriteriaComponent;
  let fixture: ComponentFixture<OptionCriteriaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OptionCriteriaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OptionCriteriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
