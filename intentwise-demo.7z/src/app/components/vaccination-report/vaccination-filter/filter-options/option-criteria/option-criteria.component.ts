import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { FilterOption } from 'src/app/models/FilterOption.model';
import { SearchParameter } from 'src/app/models/SearchParameter.model';
import { VaccinationService } from 'src/app/services/vaccination.service';

@Component({
  selector: 'app-option-criteria',
  templateUrl: './option-criteria.component.html',
  styleUrls: ['./option-criteria.component.css'],
})
export class OptionCriteriaComponent implements OnInit {
  @Input() filterOption!: FilterOption;
  @Output() filterUpdated: EventEmitter<boolean> = new EventEmitter();

  filterCriteriaForm = new FormGroup({});
  filterCriteria = new FormArray([]);
  criteriaInfo = new FormGroup({});

  clearFields = false;
  searchParameters: SearchParameter[] = [];

  criteriaVal!: string;

  constructor(private vaccinationService: VaccinationService) {}

  ngOnInit(): void {
    this.criteriaInfo = new FormGroup({
      criteria: new FormControl(),
      value: new FormControl(),
    });
    this.filterCriteria.push(this.criteriaInfo);
    this.filterCriteriaForm = new FormGroup({
      filterCriteria: this.filterCriteria,
    });

    this.patchCriteria();

    console.log('data... ', this.filterCriteriaForm.controls['filterCriteria']);
  }

  patchCriteria() {
    if (!this.clearFields) {
      for (
        let index = 0;
        index < this.filterOption.criteria.length - 1;
        index++
      )
        this.addCriteria();
    }

    const criteriaArray = this.filterCriteriaForm.get(
      'filterCriteria'
    ) as FormArray;

    for (let index = 0; index < criteriaArray.length; index++) {
      let criteria: string = this.filterOption.criteria[index];
      criteriaArray['controls'][index].patchValue({
        criteria: criteria,
        value: false,
      });
    }
  }

  addCriteria() {
    (<FormArray>this.filterCriteriaForm.get('filterCriteria')).push(
      new FormGroup({
        criteria: new FormControl(),
        value: new FormControl(),
      })
    );
  }

  onSubmit() {
    console.log('Selected search parameters --> ' + this.searchParameters);
    let status = this.vaccinationService.updateSearchFilterParameters(
      this.searchParameters
    );
    if (status) {
      this.filterUpdated.emit(status);
    }
  }

  onReset() {
    this.filterCriteriaForm.reset();
    this.clearFields = true;
    this.patchCriteria();
  }

  setFilterCondition(event: any, key: string, criteria: string, index: number) {
    if (event.target.checked) {
      this.searchParameters.push(
        new SearchParameter(
          'Vaccination',
          key,
          criteria,
          this.filterOption.operator[index],
          this.filterOption.values[index],
          event.target.checked
        )
      );
    } else {
      this.searchParameters = this.searchParameters.filter(
        (item) => item.key != key && item.criteria != criteria
      );
    }
  }
}
