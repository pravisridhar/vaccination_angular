import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FilterOption } from 'src/app/models/FilterOption.model';

@Component({
  selector: 'app-filter-options',
  templateUrl: './filter-options.component.html',
  styleUrls: ['./filter-options.component.css'],
})
export class FilterOptionsComponent implements OnInit {
  @Input() filterOptions!: FilterOption[];
  @Output() filterUpdated: EventEmitter<boolean> = new EventEmitter();
  
  selectedOption!: FilterOption;
  openCriteria : boolean = false;

  constructor() {}

  ngOnInit(): void {
    console.log(this.filterOptions);
  }

  selectFilterOption(event: any, key: string) {
    this.selectedOption = this.filterOptions.filter(
      (option) => option.key === key
    )[0];
    console.log(this.selectedOption);
    this.openCriteria = event.target.checked;
  }

  filterUpdateHandler(status: boolean) {
    if(status)
      this.filterUpdated.emit(status);
  }
}
