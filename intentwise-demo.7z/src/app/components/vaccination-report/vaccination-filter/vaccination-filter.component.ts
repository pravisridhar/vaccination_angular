import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FilterOption } from 'src/app/models/FilterOption.model';
import { VaccinationService } from 'src/app/services/vaccination.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-vaccination-filter',
  templateUrl: './vaccination-filter.component.html',
  styleUrls: ['./vaccination-filter.component.css']
})
export class VaccinationFilterComponent implements OnInit {

  filterTable : string = "";
  filterOptions : FilterOption[] = [];
  filterCount : number = 0;
  @Output() filterUpdated: EventEmitter<boolean> = new EventEmitter();

  constructor(private vaccineService : VaccinationService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.setFilterTable('Vaccination');  
  }

  setFilterTable(table: string) {
    this.filterTable = table;
    this.filterOptions = this.vaccineService.getFilterOptions(table);
  }

  showFilterOptions(content: any) {
    this.modalService.open(content,
    {}).result.then((result) => {
      console.log(`Modal Window closed with ${result}`);
    }, (reason) => {
      console.log(`Modal Window dismissed ${reason}`);
    });
  }

  filterUpdateHandler(status: boolean) {
    if(status)
      this.filterCount = this.vaccineService.fetchSearchParameters().length;
    console.log(this.vaccineService.fetchSearchParameters());
    this.modalService.dismissAll();
    this.filterUpdated.emit(status);
  }
}
