import { Component, OnInit } from '@angular/core';
import { SearchParameter } from 'src/app/models/SearchParameter.model';
import { VaccinationService } from 'src/app/services/vaccination.service';

@Component({
  selector: 'app-filter-panel',
  templateUrl: './filter-panel.component.html',
  styleUrls: ['./filter-panel.component.css']
})
export class FilterPanelComponent implements OnInit {

  filterParameters : SearchParameter[] = [];
  constructor(private vaccinationService: VaccinationService) { }

  ngOnInit(): void {
    this.filterParameters = this.vaccinationService.fetchSearchParameters();
  }

}
