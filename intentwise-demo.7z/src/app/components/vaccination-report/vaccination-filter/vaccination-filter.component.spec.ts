import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VaccinationFilterComponent } from './vaccination-filter.component';

describe('VaccinationFilterComponent', () => {
  let component: VaccinationFilterComponent;
  let fixture: ComponentFixture<VaccinationFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VaccinationFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VaccinationFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
