import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { NavComponent } from './components/shared/nav/nav.component';
import { VaccinationReportComponent } from './components/vaccination-report/vaccination-report.component';
import { VaccinationChartComponent } from './components/vaccination-report/vaccination-chart/vaccination-chart.component';
import { VaccinationTableComponent } from './components/vaccination-report/vaccination-table/vaccination-table.component';
import { VaccinationFilterComponent } from './components/vaccination-report/vaccination-filter/vaccination-filter.component';
import { VaccinationService } from './services/vaccination.service';
import { FilterOptionsComponent } from './components/vaccination-report/vaccination-filter/filter-options/filter-options.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OptionCriteriaComponent } from './components/vaccination-report/vaccination-filter/filter-options/option-criteria/option-criteria.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterPanelComponent } from './components/vaccination-report/vaccination-filter/filter-panel/filter-panel.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    VaccinationReportComponent,
    VaccinationChartComponent,
    VaccinationTableComponent,
    VaccinationFilterComponent,
    FilterOptionsComponent,
    OptionCriteriaComponent,
    FilterPanelComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [VaccinationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
